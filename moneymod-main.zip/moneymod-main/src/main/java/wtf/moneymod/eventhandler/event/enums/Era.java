package wtf.moneymod.eventhandler.event.enums;

public enum Era {
    PRE, POST, NONE
}
