package wtf.moneymod.client.mixin.accessors;

public interface IEntity
{
    boolean isInWeb( );
    void setInWeb( boolean state );
}