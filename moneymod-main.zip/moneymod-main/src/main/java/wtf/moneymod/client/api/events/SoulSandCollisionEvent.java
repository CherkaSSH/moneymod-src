package wtf.moneymod.client.api.events;

import wtf.moneymod.eventhandler.event.Event;

public class SoulSandCollisionEvent extends Event
{
}
