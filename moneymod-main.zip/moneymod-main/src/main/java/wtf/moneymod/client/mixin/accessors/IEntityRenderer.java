package wtf.moneymod.client.mixin.accessors;

public interface IEntityRenderer {

    void setupCamera(float partialTicks, int pass);

}
