package wtf.moneymod.client.impl.ui.click;

import wtf.moneymod.client.impl.utility.Globals;

public class Component implements Globals {
    public void render( int mouseX, int mouseY ) {}

    public void updateComponent( double mouseX, double mouseY ) {}

    public void mouseClicked( double mouseX, double mouseY, int button ) {}

    public void mouseReleased( double mouseX, double mouseY, int mouseButton ) {}

    public void keyTyped( int key ) {}

    public void setOffset( int offset ) {}

    public int getHeight( ) {return 12;}

    public void update( ) {}

}
